export default {
  backgroundColor: '#F6F5FC'
};
